package com.airportmgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirportmgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
