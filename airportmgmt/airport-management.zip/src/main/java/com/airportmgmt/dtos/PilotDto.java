package com.airportmgmt.dtos;

public class PilotDto extends ManagerDto {
	
	private Long licno;	
		
	public Long getLicno() {
		return licno;
	}
	public void setLicno(Long licno) {
		this.licno = licno;
	}
	
	
}
