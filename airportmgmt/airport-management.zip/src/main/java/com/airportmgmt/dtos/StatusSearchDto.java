package com.airportmgmt.dtos;

public interface StatusSearchDto {
	String getLocation();
	int getCapacity();
	int getAvailable();
	String getId();
}
